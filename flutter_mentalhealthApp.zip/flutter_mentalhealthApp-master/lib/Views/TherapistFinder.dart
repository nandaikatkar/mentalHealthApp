import 'package:flutter/material.dart';

class TherapistFinderAndSupport extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Therapist Finder/Support Services'),
      ),
      body: Center(
        child: Text('Therapist Finder/Support Services Page'),
      ),
    );
  }
}