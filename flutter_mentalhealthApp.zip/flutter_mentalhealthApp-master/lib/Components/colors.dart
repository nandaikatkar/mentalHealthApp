

import 'package:flutter/material.dart';

//Our default project colors

const primaryColor = Color(0xFF390da0);
const backgroundColor = Color(0xFFcfe0fa);